/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          900: '#050810',
          800: '#080c1a',
          700: '#0a0f1e',
          600: '#0d1530',
          500: '#111d40',
        },
        cyan: {
          50: '#ecfffe',
          100: '#cffafe',
          200: '#a5f3fc',
          300: '#67e8f9',
          400: '#22d3ee',
          500: '#06b6d4',
          600: '#0891b2',
          700: '#0e7490',
          800: '#155e75',
          900: '#164e63',
        },
        glow: {
          cyan: '#00d4ff',
          teal: '#00b4c8',
          blue: '#0066ff',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 6s ease-in-out infinite',
        'scan': 'scan 4s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' },
        },
        scan: {
          '0%, 100%': { transform: 'translateY(0%)', opacity: '0.6' },
          '50%': { transform: 'translateY(100%)', opacity: '1' },
        },
        glow: {
          '0%': { filter: 'drop-shadow(0 0 8px rgba(0, 212, 255, 0.4))' },
          '100%': { filter: 'drop-shadow(0 0 20px rgba(0, 212, 255, 0.9))' },
        },
      },
      boxShadow: {
        'cyan': '0 0 20px rgba(0, 212, 255, 0.3)',
        'cyan-lg': '0 0 40px rgba(0, 212, 255, 0.5)',
        'cyan-xl': '0 0 60px rgba(0, 212, 255, 0.7)',
      },
    },
  },
  plugins: [],
};

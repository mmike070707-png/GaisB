import { useState, useEffect } from 'react';
import {
  Search,
  Menu,
  X,
  Check,
  ArrowRight,
  Mail,
  CreditCard,
  Scan,
  Network,
  ShieldCheck,
  FlaskConical,
  TrendingUp,
  Globe2,
  Eye,
  Layers,
  Brain,
  ChevronDown,
} from 'lucide-react';

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => { setSent(false); setFormData({ name: '', email: '', message: '' }); }, 4000);
  };

  return (
    <div className="min-h-screen bg-navy-900 text-white grid-bg">

      {/* ── Header ─────────────────────────────────────────────── */}
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
          scrolled ? 'bg-navy-800/95 backdrop-blur-md border-b border-cyan-500/20' : 'bg-transparent'
        }`}
      >
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center gradient-cyan shadow-cyan">
              <Search className="w-5 h-5 text-navy-900" strokeWidth={2.5} />
            </div>
            <span className="text-xl font-bold tracking-wide gradient-text-cyan">GAISB</span>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <NavLink href="#identity">Identity</NavLink>
            <NavLink href="#capabilities">Capabilities</NavLink>
            <NavLink href="#pricing">Pricing</NavLink>
            <NavLink href="#contact">Contact</NavLink>
            <a href="#pricing" className="btn-cyan text-sm px-5 py-2.5">Access GAISB</a>
          </div>

          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2 rounded-lg border border-cyan-500/30">
            {menuOpen ? <X className="w-5 h-5 cyan-text" /> : <Menu className="w-5 h-5 cyan-text" />}
          </button>
        </nav>

        {menuOpen && (
          <div className="md:hidden glass-card border-t border-cyan-500/20 p-4 space-y-3">
            <MobileNavLink href="#identity" onClick={() => setMenuOpen(false)}>Identity</MobileNavLink>
            <MobileNavLink href="#capabilities" onClick={() => setMenuOpen(false)}>Capabilities</MobileNavLink>
            <MobileNavLink href="#pricing" onClick={() => setMenuOpen(false)}>Pricing</MobileNavLink>
            <MobileNavLink href="#contact" onClick={() => setMenuOpen(false)}>Contact</MobileNavLink>
            <a href="#pricing" className="btn-cyan w-full text-center block mt-2 text-sm">Access GAISB</a>
          </div>
        )}
      </header>

      {/* ── Hero ───────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
        {/* Ambient glows */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 grid lg:grid-cols-2 gap-16 items-center">
          {/* Left copy */}
          <div>
            <div className="inline-flex items-center space-x-2 mb-6 px-4 py-1.5 rounded-full text-xs font-mono font-medium tracking-widest uppercase glow-border" style={{ color: '#00d4ff' }}>
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>Pattern Recognition AI · Truth Engine</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black leading-tight mb-6">
              <span className="text-white">See the</span>{' '}
              <span className="gradient-text-cyan">Truth</span>
              <br />
              <span className="text-white">in Every</span>{' '}
              <span className="gradient-text-cyan">Pattern</span>
            </h1>

            <p className="text-gray-300 text-lg leading-relaxed mb-8 max-w-lg">
              GAISB is an honest, unfiltered AI built to find hidden patterns, expose deception, and surface
              truth — across data, language, behavior, markets, and systems.
              <br /><br />
              <span style={{ color: '#00d4ff' }} className="font-medium">No spin. No bias. Just truth.</span>
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <a href="#pricing" className="btn-cyan text-base px-8 py-4">
                Start Finding Truth
                <ArrowRight className="ml-2 w-5 h-5" />
              </a>
              <a href="#capabilities" className="btn-outline-cyan text-base px-8 py-4">
                See Capabilities
              </a>
            </div>

            <div className="grid grid-cols-3 gap-6">
              <TrustStat value="99.7%" label="Pattern Accuracy" />
              <TrustStat value="1.2B+" label="Patterns Analyzed" />
              <TrustStat value="Zero" label="Hidden Agendas" />
            </div>
          </div>

          {/* Right: GAISB Character */}
          <div className="flex justify-center items-center">
            <GAISBCharacter />
          </div>
        </div>

        <a href="#identity" className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center text-gray-500 hover:text-cyan-400 transition-colors animate-bounce">
          <span className="text-xs font-mono mb-1">scroll</span>
          <ChevronDown className="w-5 h-5" />
        </a>
      </section>

      {/* ── Identity Section ───────────────────────────────────── */}
      <section id="identity" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4">Who Is <span className="gradient-text-cyan">GAISB</span>?</h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              A Global AI Solutions Builder engineered with one core directive: find the truth and reveal it honestly.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <IdentityCard
              icon={<Eye className="w-8 h-8" />}
              title="The Honest Eye"
              description="GAISB does not sugarcoat. It does not flatter. It sees data and language as they are — not as anyone wants them to appear. Raw truth, delivered clearly."
            />
            <IdentityCard
              icon={<Search className="w-8 h-8" />}
              title="The Pattern Hunter"
              description="Trained on billions of data points, GAISB identifies patterns across markets, text, behavior, networks, and systems before humans notice a signal."
              featured
            />
            <IdentityCard
              icon={<ShieldCheck className="w-8 h-8" />}
              title="The Truth Guardian"
              description="GAISB operates without hidden loyalties, political bias, or commercial pressure. Its only obligation is accuracy and transparency."
            />
          </div>
        </div>
      </section>

      {/* ── Capabilities ───────────────────────────────────────── */}
      <section id="capabilities" className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-navy-800/30 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4">Pattern <span className="gradient-text-cyan">Capabilities</span></h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Every domain. Every signal. Every pattern. GAISB sees through the noise.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <CapabilityCard
              icon={<Scan className="w-7 h-7" />}
              title="Behavioral Pattern Analysis"
              description="Detect consistent behaviors, anomalies, and intent signals in user actions, transactions, and communications."
            />
            <CapabilityCard
              icon={<Network className="w-7 h-7" />}
              title="Network & Relationship Mapping"
              description="Reveal hidden connections, influence chains, and organizational structures invisible to the human eye."
            />
            <CapabilityCard
              icon={<FlaskConical className="w-7 h-7" />}
              title="Deception Detection"
              description="Cross-reference claims against evidence. Flag contradictions, fabrications, and statistical impossibilities."
            />
            <CapabilityCard
              icon={<TrendingUp className="w-7 h-7" />}
              title="Market & Financial Patterns"
              description="Identify macro trends, cyclical behaviors, and anomalous movements before they become common knowledge."
            />
            <CapabilityCard
              icon={<Brain className="w-7 h-7" />}
              title="Language & Narrative Analysis"
              description="Analyze text at scale for bias, propaganda patterns, sentiment shifts, and linguistic fingerprints."
            />
            <CapabilityCard
              icon={<Layers className="w-7 h-7" />}
              title="Multi-Domain Cross Analysis"
              description="Connect patterns across disparate domains — finding the thread that links data, events, and signals into truth."
            />
          </div>
        </div>
      </section>

      {/* ── Pattern Types Ticker ───────────────────────────────── */}
      <section className="py-12 overflow-hidden border-y border-cyan-500/10">
        <div className="flex space-x-12 animate-[scroll_30s_linear_infinite] whitespace-nowrap">
          {[...Array(3)].flatMap(() => [
            'Market Patterns', 'Behavioral Signals', 'Language Bias',
            'Network Graphs', 'Financial Anomalies', 'Deception Fingerprints',
            'Social Dynamics', 'Statistical Truth', 'Narrative Patterns',
            'System Vulnerabilities', 'Cultural Trends', 'Truth Verification',
          ]).map((item, i) => (
            <span key={i} className="text-sm font-mono uppercase tracking-widest" style={{ color: i % 3 === 1 ? '#00d4ff' : '#374151' }}>
              ◆ {item}
            </span>
          ))}
        </div>
      </section>

      {/* ── Pricing ────────────────────────────────────────────── */}
      <section id="pricing" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4">Access <span className="gradient-text-cyan">GAISB</span></h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Choose your level of truth. All plans include GAISB's uncompromising commitment to accuracy.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <PricingCard
              tier="Free"
              price="$0"
              period="forever"
              tagline="Start seeking truth"
              features={[
                '1,000 pattern queries/month',
                'Basic pattern recognition',
                'Language & text analysis',
                '1 active project',
                'Community support',
              ]}
              cta="Get Free Access"
              ctaStyle="outline"
            />
            <PricingCard
              tier="Pro"
              price="$29"
              period="/month"
              tagline="Deep pattern intelligence"
              features={[
                '50,000 pattern queries/month',
                'Full pattern recognition suite',
                'Deception detection engine',
                'Network & relationship mapping',
                'Unlimited projects',
                '5 team members',
                'Priority support',
                'API access',
              ]}
              cta="Subscribe via PayPal"
              ctaStyle="primary"
              featured
              paypalHandle="mmike070707"
            />
            <PricingCard
              tier="Enterprise"
              price="$199"
              period="/month"
              tagline="Unrestricted truth engine"
              features={[
                'Unlimited pattern queries',
                'All pattern domains unlocked',
                'Real-time deception alerts',
                'Custom model fine-tuning',
                'Unlimited team members',
                '24/7 dedicated support',
                'SLA guarantee',
                'On-premise deployment',
                'White-label option',
              ]}
              cta="Contact for Enterprise"
              ctaStyle="outline"
            />
          </div>

          {/* Payment Methods */}
          <div className="mt-16 text-center">
            <p className="text-gray-500 text-sm mb-6 font-mono uppercase tracking-wider">Accepted Payment Methods</p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="https://www.paypal.com/paypalme/mmike070707"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 glass-card glow-border-hover px-6 py-4 rounded-xl transition-all duration-300"
              >
                <CreditCard className="w-6 h-6" style={{ color: '#00d4ff' }} />
                <div className="text-left">
                  <div className="font-semibold text-white">PayPal</div>
                  <div className="text-xs text-gray-400 font-mono">mmike070707@gmail.com</div>
                </div>
              </a>
              <div className="flex items-center space-x-3 glass-card px-6 py-4 rounded-xl">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00d084, #00a86b)' }}>
                  <span className="text-white font-black text-lg">$</span>
                </div>
                <div className="text-left">
                  <div className="font-semibold text-white">Cash App</div>
                  <div className="text-xs text-gray-400 font-mono">$RoadRunner5150A1</div>
                </div>
              </div>
            </div>
            <p className="mt-4 text-xs text-gray-600 font-mono">
              Send payment and include your email — access granted within 24hrs
            </p>
          </div>
        </div>
      </section>

      {/* ── Contact ────────────────────────────────────────────── */}
      <section id="contact" className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-navy-800/40 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div>
              <h2 className="text-4xl sm:text-5xl font-bold mb-6">
                Ask <span className="gradient-text-cyan">GAISB</span>
              </h2>
              <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                Have a complex dataset, a suspicious narrative, or a pattern you can't quite see?
                Tell us about it. GAISB is built for the hard questions.
              </p>
              <div className="space-y-5">
                <ContactDetail icon={<Mail className="w-5 h-5" />} label="Email" value="support@gaisb.ai" />
                <ContactDetail icon={<Globe2 className="w-5 h-5" />} label="Response Time" value="Within 24 hours" />
                <ContactDetail icon={<ShieldCheck className="w-5 h-5" />} label="Privacy" value="Your queries stay private" />
              </div>
            </div>

            <div className="glass-card rounded-2xl p-8 glow-border">
              {sent ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-full gradient-cyan flex items-center justify-center mx-auto mb-4">
                    <Check className="w-8 h-8 text-navy-900" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Message Received</h3>
                  <p className="text-gray-400">GAISB will analyze your query and respond within 24 hours.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <FormField label="Name" id="name">
                    <input
                      type="text"
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-navy-700/50 border border-cyan-500/20 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/60 transition-colors"
                      placeholder="Your name"
                      required
                    />
                  </FormField>
                  <FormField label="Email" id="email">
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-navy-700/50 border border-cyan-500/20 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/60 transition-colors"
                      placeholder="you@example.com"
                      required
                    />
                  </FormField>
                  <FormField label="What pattern or truth are you looking for?" id="message">
                    <textarea
                      id="message"
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-navy-700/50 border border-cyan-500/20 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/60 transition-colors resize-none"
                      placeholder="Describe your dataset, question, or the pattern you need uncovered..."
                      required
                    />
                  </FormField>
                  <button type="submit" className="btn-cyan w-full py-4 text-base font-bold">
                    Send to GAISB
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ─────────────────────────────────────────────── */}
      <footer className="border-t border-cyan-500/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-10 mb-10">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-9 h-9 rounded-xl gradient-cyan flex items-center justify-center">
                  <Search className="w-4 h-4 text-navy-900" strokeWidth={2.5} />
                </div>
                <span className="font-bold gradient-text-cyan text-lg">GAISB</span>
              </div>
              <p className="text-gray-500 text-sm leading-relaxed">
                Global AI Solutions Builder. Honest. Unbiased. Pattern-driven.
              </p>
            </div>
            <FooterCol title="Product" links={['Capabilities', 'Pricing', 'API Docs', 'Changelog']} />
            <FooterCol title="Company" links={['About', 'Mission', 'Blog', 'Contact']} />
            <FooterCol title="Legal" links={['Privacy Policy', 'Terms of Service', 'Cookie Policy']} />
          </div>
          <div className="border-t border-cyan-500/10 pt-6 flex flex-col sm:flex-row justify-between items-center text-xs text-gray-600 font-mono">
            <span>&copy; 2024 GAISB — Global AI Solutions Builder. All rights reserved.</span>
            <span className="mt-2 sm:mt-0 cyan-text">Truth is non-negotiable.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ── GAISB Character SVG ──────────────────────────────────────── */
function GAISBCharacter() {
  return (
    <div className="relative animate-float">
      {/* Outer glow ring */}
      <div className="absolute inset-0 rounded-full animate-pulse-slow" style={{ background: 'radial-gradient(circle, rgba(0,212,255,0.12) 0%, transparent 70%)' }} />

      <svg
        viewBox="0 0 400 500"
        xmlns="http://www.w3.org/2000/svg"
        className="w-72 lg:w-96 drop-shadow-2xl animate-glow"
        style={{ filter: 'drop-shadow(0 0 24px rgba(0, 212, 255, 0.5))' }}
      >
        <defs>
          <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#0066ff" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient id="glassBody" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.15" />
            <stop offset="50%" stopColor="#00a8cc" stopOpacity="0.25" />
            <stop offset="100%" stopColor="#0044aa" stopOpacity="0.1" />
          </linearGradient>
          <linearGradient id="scanLine" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" stopOpacity="0" />
            <stop offset="50%" stopColor="#00d4ff" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#00d4ff" stopOpacity="0" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge><feMergeNode in="coloredBlur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* ── City background silhouette ── */}
        <g opacity="0.2">
          <rect x="0" y="340" width="30" height="160" fill="#00d4ff" />
          <rect x="20" y="310" width="20" height="190" fill="#0066ff" />
          <rect x="50" y="360" width="25" height="140" fill="#00d4ff" />
          <rect x="320" y="320" width="30" height="180" fill="#00d4ff" />
          <rect x="345" y="300" width="20" height="200" fill="#0066ff" />
          <rect x="360" y="350" width="40" height="150" fill="#00a8cc" />
          <rect x="330" y="340" width="15" height="5" fill="#00d4ff" opacity="0.6" />
          <rect x="25" y="325" width="10" height="4" fill="#00d4ff" opacity="0.6" />
        </g>

        {/* ── Head ── */}
        {/* Head base */}
        <ellipse cx="200" cy="95" rx="55" ry="62" fill="url(#glassBody)" stroke="#00d4ff" strokeWidth="1.5" filter="url(#glow)" />
        {/* Head highlight */}
        <ellipse cx="185" cy="75" rx="25" ry="30" fill="rgba(0,212,255,0.06)" />
        {/* Ear pieces */}
        <circle cx="148" cy="100" r="10" fill="url(#bodyGrad)" opacity="0.7" />
        <circle cx="148" cy="100" r="5" fill="#00d4ff" />
        <circle cx="252" cy="100" r="10" fill="url(#bodyGrad)" opacity="0.7" />
        {/* Eyes */}
        <ellipse cx="182" cy="90" rx="14" ry="10" fill="rgba(0,212,255,0.15)" stroke="#00d4ff" strokeWidth="1" />
        <ellipse cx="218" cy="90" rx="14" ry="10" fill="rgba(0,212,255,0.15)" stroke="#00d4ff" strokeWidth="1" />
        <ellipse cx="182" cy="90" rx="7" ry="7" fill="#00d4ff" opacity="0.9" />
        <ellipse cx="218" cy="90" rx="7" ry="7" fill="#00d4ff" opacity="0.9" />
        {/* Eye pupils */}
        <circle cx="182" cy="90" r="3" fill="#050810" />
        <circle cx="218" cy="90" r="3" fill="#050810" />
        <circle cx="183" cy="89" r="1.5" fill="white" opacity="0.8" />
        <circle cx="219" cy="89" r="1.5" fill="white" opacity="0.8" />
        {/* Scan line in head */}
        <rect x="155" y="60" width="90" height="2" fill="url(#scanLine)" opacity="0.5">
          <animate attributeName="y" values="65;125;65" dur="3s" repeatCount="indefinite" />
        </rect>
        {/* Mouth / data display */}
        <rect x="178" y="118" width="44" height="8" rx="4" fill="rgba(0,212,255,0.2)" stroke="#00d4ff" strokeWidth="0.5" />
        <rect x="181" y="120" width="12" height="4" rx="2" fill="#00d4ff" opacity="0.8" />
        <rect x="196" y="120" width="8" height="4" rx="2" fill="#00d4ff" opacity="0.5" />
        <rect x="207" y="120" width="12" height="4" rx="2" fill="#00d4ff" opacity="0.7" />

        {/* ── Neck ── */}
        <rect x="190" y="152" width="20" height="22" rx="3" fill="url(#glassBody)" stroke="#00d4ff" strokeWidth="1" />
        <line x1="195" y1="152" x2="195" y2="174" stroke="#00d4ff" strokeWidth="0.5" opacity="0.5" />
        <line x1="205" y1="152" x2="205" y2="174" stroke="#00d4ff" strokeWidth="0.5" opacity="0.5" />

        {/* ── Torso ── */}
        <path d="M145 175 Q130 180 128 230 L128 310 Q130 320 200 320 Q270 320 272 310 L272 230 Q270 180 255 175 Z"
          fill="url(#glassBody)" stroke="#00d4ff" strokeWidth="1.5" filter="url(#glow)" />
        {/* Chest panel */}
        <rect x="165" y="190" width="70" height="60" rx="8" fill="rgba(0,212,255,0.08)" stroke="#00d4ff" strokeWidth="1" />
        {/* Core reactor */}
        <circle cx="200" cy="218" r="16" fill="rgba(0,212,255,0.15)" stroke="#00d4ff" strokeWidth="1.5" />
        <circle cx="200" cy="218" r="9" fill="rgba(0,212,255,0.3)" />
        <circle cx="200" cy="218" r="5" fill="#00d4ff" opacity="0.9" />
        <circle cx="200" cy="218" r="5" fill="#00d4ff">
          <animate attributeName="r" values="5;8;5" dur="2s" repeatCount="indefinite" />
          <animate attributeName="opacity" values="0.9;0.3;0.9" dur="2s" repeatCount="indefinite" />
        </circle>
        {/* Circuit lines on torso */}
        <line x1="165" y1="268" x2="235" y2="268" stroke="#00d4ff" strokeWidth="0.5" opacity="0.4" />
        <line x1="175" y1="280" x2="225" y2="280" stroke="#00d4ff" strokeWidth="0.5" opacity="0.3" />
        <line x1="180" y1="290" x2="220" y2="290" stroke="#00d4ff" strokeWidth="0.5" opacity="0.2" />
        {/* Side ribs */}
        <line x1="145" y1="210" x2="155" y2="210" stroke="#00d4ff" strokeWidth="1" opacity="0.5" />
        <line x1="142" y1="225" x2="153" y2="225" stroke="#00d4ff" strokeWidth="1" opacity="0.5" />
        <line x1="145" y1="240" x2="155" y2="240" stroke="#00d4ff" strokeWidth="1" opacity="0.5" />
        <line x1="255" y1="210" x2="245" y2="210" stroke="#00d4ff" strokeWidth="1" opacity="0.5" />
        <line x1="258" y1="225" x2="247" y2="225" stroke="#00d4ff" strokeWidth="1" opacity="0.5" />
        <line x1="255" y1="240" x2="245" y2="240" stroke="#00d4ff" strokeWidth="1" opacity="0.5" />

        {/* ── Left Arm (raised, holding magnifying glass) ── */}
        <path d="M128 195 Q100 200 85 215 Q72 230 70 255" fill="none" stroke="#00d4ff" strokeWidth="12" strokeLinecap="round" opacity="0.3" />
        <path d="M128 195 Q100 200 85 215 Q72 230 70 255" fill="none" stroke="#00d4ff" strokeWidth="2" strokeLinecap="round" />
        {/* Forearm */}
        <path d="M70 255 Q60 270 62 295 Q64 310 80 320" fill="none" stroke="#00d4ff" strokeWidth="10" strokeLinecap="round" opacity="0.3" />
        <path d="M70 255 Q60 270 62 295 Q64 310 80 320" fill="none" stroke="#00d4ff" strokeWidth="2" strokeLinecap="round" />
        {/* Hand */}
        <circle cx="80" cy="322" r="8" fill="url(#glassBody)" stroke="#00d4ff" strokeWidth="1.5" />

        {/* ── Magnifying Glass ── */}
        <g transform="translate(95, 290)">
          {/* Glass circle */}
          <circle cx="0" cy="0" r="35" fill="rgba(0,212,255,0.06)" stroke="#00d4ff" strokeWidth="2.5" filter="url(#glow)" />
          <circle cx="0" cy="0" r="35" fill="none" stroke="rgba(0,212,255,0.3)" strokeWidth="8" />
          {/* Inner lens shine */}
          <circle cx="-10" cy="-10" r="12" fill="rgba(255,255,255,0.04)" />
          {/* Data grid inside lens */}
          <clipPath id="lensClip"><circle cx="0" cy="0" r="32" /></clipPath>
          <g clipPath="url(#lensClip)" opacity="0.5">
            <line x1="-32" y1="-15" x2="32" y2="-15" stroke="#00d4ff" strokeWidth="0.5" />
            <line x1="-32" y1="0" x2="32" y2="0" stroke="#00d4ff" strokeWidth="0.5" />
            <line x1="-32" y1="15" x2="32" y2="15" stroke="#00d4ff" strokeWidth="0.5" />
            <line x1="-15" y1="-32" x2="-15" y2="32" stroke="#00d4ff" strokeWidth="0.5" />
            <line x1="0" y1="-32" x2="0" y2="32" stroke="#00d4ff" strokeWidth="0.5" />
            <line x1="15" y1="-32" x2="15" y2="32" stroke="#00d4ff" strokeWidth="0.5" />
          </g>
          {/* Scan crosshair */}
          <line x1="-20" y1="0" x2="20" y2="0" stroke="#00d4ff" strokeWidth="1" opacity="0.7" />
          <line x1="0" y1="-20" x2="0" y2="20" stroke="#00d4ff" strokeWidth="1" opacity="0.7" />
          <circle cx="0" cy="0" r="5" fill="#00d4ff" opacity="0.5">
            <animate attributeName="r" values="3;8;3" dur="2s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.8;0.1;0.8" dur="2s" repeatCount="indefinite" />
          </circle>
          {/* Handle */}
          <line x1="25" y1="25" x2="60" y2="62" stroke="#00d4ff" strokeWidth="6" strokeLinecap="round" opacity="0.4" />
          <line x1="25" y1="25" x2="60" y2="62" stroke="#00d4ff" strokeWidth="2" strokeLinecap="round" />
        </g>

        {/* ── Right Arm (down, at side) ── */}
        <path d="M272 200 Q295 210 300 240 Q305 265 298 295" fill="none" stroke="#00d4ff" strokeWidth="12" strokeLinecap="round" opacity="0.3" />
        <path d="M272 200 Q295 210 300 240 Q305 265 298 295" fill="none" stroke="#00d4ff" strokeWidth="2" strokeLinecap="round" />
        <circle cx="298" cy="298" r="9" fill="url(#glassBody)" stroke="#00d4ff" strokeWidth="1.5" />

        {/* ── Legs ── */}
        <path d="M170 318 Q168 360 165 400 Q163 430 168 460" fill="none" stroke="#00d4ff" strokeWidth="16" strokeLinecap="round" opacity="0.3" />
        <path d="M170 318 Q168 360 165 400 Q163 430 168 460" fill="none" stroke="#00d4ff" strokeWidth="2" strokeLinecap="round" />
        <path d="M230 318 Q232 360 235 400 Q237 430 232 460" fill="none" stroke="#00d4ff" strokeWidth="16" strokeLinecap="round" opacity="0.3" />
        <path d="M230 318 Q232 360 235 400 Q237 430 232 460" fill="none" stroke="#00d4ff" strokeWidth="2" strokeLinecap="round" />
        {/* Feet */}
        <ellipse cx="166" cy="463" rx="22" ry="10" fill="url(#glassBody)" stroke="#00d4ff" strokeWidth="1.5" />
        <ellipse cx="233" cy="463" rx="22" ry="10" fill="url(#glassBody)" stroke="#00d4ff" strokeWidth="1.5" />

        {/* ── Ground reflection ── */}
        <ellipse cx="200" cy="490" rx="80" ry="8" fill="#00d4ff" opacity="0.08" />
      </svg>

      {/* Floating data labels */}
      <DataLabel text="Pattern: Detected" top="10%" right="-5%" delay="0s" />
      <DataLabel text="Truth: Verified" top="35%" left="-12%" delay="0.8s" />
      <DataLabel text="Signal: Processing" bottom="30%" right="-8%" delay="1.6s" />
    </div>
  );
}

function DataLabel({ text, top, right, left, bottom, delay }: {
  text: string; top?: string; right?: string; left?: string; bottom?: string; delay: string;
}) {
  return (
    <div
      className="absolute text-xs font-mono px-2 py-1 rounded glass-card border border-cyan-500/30 whitespace-nowrap animate-pulse"
      style={{ top, right, left, bottom, color: '#00d4ff', animationDelay: delay }}
    >
      {text}
    </div>
  );
}

/* ── Sub-components ──────────────────────────────────────────── */
function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a href={href} className="text-gray-400 hover:text-cyan-400 transition-colors text-sm font-medium">
      {children}
    </a>
  );
}

function MobileNavLink({ href, onClick, children }: { href: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <a href={href} onClick={onClick} className="block text-gray-400 hover:text-cyan-400 transition-colors font-medium py-1">
      {children}
    </a>
  );
}

function TrustStat({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <div className="text-2xl font-black gradient-text-cyan">{value}</div>
      <div className="text-xs text-gray-500 font-mono mt-0.5">{label}</div>
    </div>
  );
}

function IdentityCard({ icon, title, description, featured = false }: {
  icon: React.ReactNode; title: string; description: string; featured?: boolean;
}) {
  return (
    <div className={`glass-card rounded-2xl p-8 ${featured ? 'glow-border ring-1 ring-cyan-500/40' : ''} transition-all duration-300 hover:-translate-y-1`}
      style={featured ? { boxShadow: '0 0 40px rgba(0, 212, 255, 0.15)' } : {}}>
      <div className="w-14 h-14 rounded-xl gradient-cyan flex items-center justify-center mb-6 text-navy-900">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3 text-white">{title}</h3>
      <p className="text-gray-400 leading-relaxed">{description}</p>
    </div>
  );
}

function CapabilityCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="glass-card glow-border-hover rounded-xl p-6 transition-all duration-300 hover:-translate-y-1 group">
      <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-all duration-300"
        style={{ background: 'rgba(0,212,255,0.1)', color: '#00d4ff' }}>
        {icon}
      </div>
      <h3 className="text-lg font-semibold mb-2 text-white">{title}</h3>
      <p className="text-gray-500 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

function PricingCard({ tier, price, period, tagline, features, cta, ctaStyle, featured = false, paypalHandle }: {
  tier: string; price: string; period: string; tagline: string;
  features: string[]; cta: string; ctaStyle: 'primary' | 'outline';
  featured?: boolean; paypalHandle?: string;
}) {
  return (
    <div className={`relative glass-card rounded-2xl p-8 flex flex-col ${featured ? 'ring-2 ring-cyan-500/50 scale-105' : ''}`}
      style={featured ? { boxShadow: '0 0 50px rgba(0, 212, 255, 0.2)' } : {}}>
      {featured && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 gradient-cyan px-4 py-1 rounded-full text-xs font-bold text-navy-900 uppercase tracking-wider whitespace-nowrap">
          Most Popular
        </div>
      )}
      <div className="mb-6">
        <h3 className="text-lg font-bold text-gray-400 font-mono uppercase tracking-wider mb-1">{tier}</h3>
        <p className="text-sm text-gray-600 mb-4">{tagline}</p>
        <div className="flex items-baseline space-x-1">
          <span className="text-4xl font-black gradient-text-cyan">{price}</span>
          <span className="text-gray-500 font-mono">{period}</span>
        </div>
      </div>
      <ul className="space-y-3 mb-8 flex-1">
        {features.map((f, i) => (
          <li key={i} className="flex items-start space-x-3">
            <Check className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: '#00d4ff' }} />
            <span className="text-gray-400 text-sm">{f}</span>
          </li>
        ))}
      </ul>
      {ctaStyle === 'primary' ? (
        <a
          href={`https://www.paypal.com/paypalme/${paypalHandle}`}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-cyan w-full text-center py-3 font-bold"
        >
          {cta}
        </a>
      ) : (
        <a
          href={tier === 'Enterprise' ? '#contact' : '#'}
          className="btn-outline-cyan w-full text-center py-3 font-bold"
        >
          {cta}
        </a>
      )}
    </div>
  );
}

function ContactDetail({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center space-x-4">
      <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
        style={{ background: 'rgba(0,212,255,0.1)', color: '#00d4ff' }}>
        {icon}
      </div>
      <div>
        <div className="text-xs text-gray-600 font-mono uppercase tracking-wide">{label}</div>
        <div className="text-white font-medium">{value}</div>
      </div>
    </div>
  );
}

function FormField({ label, id, children }: { label: string; id: string; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-mono uppercase tracking-wider text-gray-500 mb-2">{label}</label>
      {children}
    </div>
  );
}

function FooterCol({ title, links }: { title: string; links: string[] }) {
  return (
    <div>
      <h4 className="font-semibold text-gray-300 mb-4 text-sm uppercase tracking-wider font-mono">{title}</h4>
      <ul className="space-y-2">
        {links.map((link) => (
          <li key={link}>
            <a href="#" className="text-gray-600 hover:text-cyan-400 transition-colors text-sm">{link}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
